print("####################")
print("Seja Bem Vindo ao cinema Belas Artes")
print("Por Favor,digite sua idade")
print("####################")

#Declarando a variavel idade tem o valor 39
idade=int(input("")) #int(str) -> saida de um inteiro
# Solicitando  que o usario digite a idade
#str >int

if idade > 18:
    print("Pode assitir o filme!")
else:
    print("Voce não pode assistir o filme!")
