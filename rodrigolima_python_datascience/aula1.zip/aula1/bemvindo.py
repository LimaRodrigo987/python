print("Olá,mundo!")
print("Primeiro dia de data science!")